import os
import random
import copy
import entities
import sys
import time
import colorAdd
import intro

global prearray
global entitylist
global player
global colors 
colors = colorAdd.colors()
entitylist =[]

#==================================================================================================
#GETCH from Louis on Stackoverflow
def _find_getch():
    try:
        import termios
    except ImportError:
        # Non-POSIX. Return msvcrt's (Windows') getch.
        import msvcrt
        return msvcrt.getch
    # POSIX system. Create and return a getch that manipulates the tty.
    import sys, tty
    def _getch():
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch
    return _getch
getch = _find_getch()
#==================================================================================================

#==============================
#READING SOME TXT FILES
global aimDict
aimDict = {'n':open('art\\aim1.txt','rU').read(), 's':open('art\\aim2.txt','rU').read(), 'e':open('art\\aim3.txt','rU').read(), 'w':open('art\\aim4.txt','rU').read()}





#==================================================================================================
#SECTION ONE, prearray, MAP GENERATION

#"C:\Program Files\IBM\SPSS\Statistics\22\Python\python.exe" l.py
def strsurgery(string,index,replace):
	temp1 = string[0:index]
	temp2 = string[(index+1):]
	final = temp1 + replace + temp2
	return final

	
def resize(height,width):
	global prearray
	mode = "mode con: cols=" + str(width + 60) + " lines=" + str(height + 15)
	os.system(mode)
	
	prearray = []

	ct  = 0
	while ct < height:
		prearray.append("")
		ct += 1
		
	for n in range(width):
		ct = 0
		while ct < width:
			prearray[n]+= "#"
			ct += 1
			
def assembleWorkingMap():
	printarray = copy.deepcopy(prearray)
	for element in entitylist:
		printarray[element.Y] = strsurgery(printarray[element.Y],element.X,element.symbol)
	return printarray
			
def printg():
	# processing sidepane file
	sidepaneFile = open("art\\face.txt",'rU')
	sidepaneString = sidepaneFile.read()
	sidepane = sidepaneString.split('\n')
	# end
	
	os.system("cls")
	print ""
	printstring = ""
	printarray = assembleWorkingMap()
	for num in range(0, len(printarray)-1):
		printstring +=  "    " + printarray[num] + "   " + sidepane[num] + "\n"
	reallyprintstring = ''
	for c in printstring:
		reallyprintstring += colors.appendColor(c)
	print reallyprintstring
	
	# info bar
	
	print colors.colorize( "|========================================================================================|" , 'black', 'green')
	infobar = '\n'
	infobar += colors.colorize( "REGISTERED PILOT: ", 'yellow', 'black') 
	infobar += colors.colorize( player.name[0:6], 'black', 'orange')
	infobar += colors.colorize( "    HULL INTEGRITY: ", 'yellow', 'black')
	if player.health > 0.5*(player.health):
		infobar += colors.colorize( str(player.health) + " ...OK        ", 'black', 'green')
	elif player.health > 0.25*(player.health):
		infobar += colors.colorize( str(player.health) + " ...Watch it! ", 'black', 'orange')
	else:
		infobar += colors.colorize( str(player.health) + " ...CRITICAL  ", 'black', 'red')

	infobar += colors.colorize("OFFENSIVE STRENGTH: ", 'yellow', 'black')
	infobar += colors.colorize(str(player.attack), 'red', 'black')
	
	infobar += '\n'
	
	infobar += colors.colorize("PILOT LEVEL: ", 'yellow', 'black')
	infobar += colors.colorize(str(player.level), 'black', 'cyan')
		
	print infobar
	
	print aimDict[player.aim]
	
	#handle aim pic opening
	

def ins(x,y,char): #INSERT
	prearray[y] = strsurgery(prearray[y],x,char)
	
def gen(l,type):

	if type == 'cave':
		temparray = []
		for element in prearray:
			temparray.append( "#" * 30 )
		prearray = copy.deepcopy(temparray)
		ct = 0
		genx = 15
		geny = 15
		while ct < 50 + l:
			if genx > 0 and genx < 30:
				try:
					ins(genx,geny,".")
				except:
					pass
			
			ct += 1
			genx += random.choice([-1,0,1])
			geny += random.choice([-1,0,1])
		
	if type == 'city':
		global prearray
		temparray = []
		for element in prearray:
			temparray.append( "." * 30 )
		prearray = copy.deepcopy(temparray)
		ct = 0
		while ct < 30:
			genx = 2*(int(random.random()*12)+2)
			geny = 2*(int(random.random()*12)+2)
			try:
				ins(genx,geny,"#")
				ins(genx+1,geny,"#")
				ins(genx-1,geny,"#")
				ins(genx,geny+1,"#")
				ins(genx,geny-1,"#")
				ins(genx-1,geny+1,"#")
				ins(genx-1,geny-1,"#")
				ins(genx+1,geny+1,"#")
				ins(genx+1,geny-1,"#")
			except:
				pass
			ct += 1
			
	if type == 'ravine':
		global prearray
		temparray = []
		for element in prearray:
			temparray.append( "\\" * 30 )
		prearray = copy.deepcopy(temparray)
		ct = 0
		geny = random.randint(10,20)
		genx = random.randint(10,20)
		dir = ['n','s','e','w','n','s']
		while ct < 275:
			try:
				if genx > 0 and genx < 30:
					ins(genx,geny,".")
			except:
				pass
			thisdir = random.choice(dir)
			if thisdir == 'n':
				geny += 1
				dir.append('n')
			if thisdir == 's':
				geny -= 1
				dir.append('s')
			if thisdir == 'w':
				genx -= 1
				dir.append('w')
			if thisdir == 'e':
				genx += 1
				dir.append('e')
			ct += 1
	colors.makeLevelDict(type)
	colors.makeBackDict(type)
			

def spawn(l):
	global entitylist
	ct = 0
	while ct < 1:
		spax = random.randint(1,29)
		spay = random.randint(1,29)
		if prearray[spay][spax] == ".":
			global player
			player = entities.player("player","@",10,1,"yes",spax,spay)
			entitylist.append(player)
			ct += 1
			
	ct = 0
	monsfile = open("monster.txt", "rU")
	monsstring = monsfile.read()
	monsfile.close()
	monslist = monsstring.split("\n\n")
	
	num = 0
	while num < len(monslist):
		if monslist[num][0] == "#":
			monslist.pop(num)
		else:
			monslist[num] = monslist[num].split(" ")	
			num += 1
	while ct <= (l + random.randint(2,50)):
		spax = random.randint(1,29)
		spay = random.randint(1,29)
		if prearray[spay][spax] == ".":
			monster = random.choice(monslist)
			entitylist.append(entities.monster(monster[0],monster[1],int(monster[2]),int(monster[3]), int(monster[4]), int(monster[5]), 'yes', spax, spay) )
			ct += 1
			

def scan(entity):
	adjacents = ""
	workingarray = assembleWorkingMap()
	
	try:
		if workingarray[entity.Y + 1][entity.X] != ".":
			adjacents += "s"		
		if workingarray[entity.Y - 1][entity.X] != ".":
			adjacents += "n"	
		if workingarray[entity.Y][entity.X + 1] != ".":
			adjacents += "e"	
		if workingarray[entity.Y][entity.X - 1] != ".":
			adjacents += "w"
	except:
		pass
	return adjacents		
		
def start():
	print 60 * '\n'
	os.system('')
	resize(30,30)
	intro.intro()
	gen(1,random.choice(['cave','city','ravine']) )
	spawn(1)
	printg()
	
start()

while player.health > 0:
	playerinput = getch()
	if playerinput == "q":
		sys.exit("Quit gem.")
	player.handle(playerinput, scan(player), prearray)
	for element in entitylist:
		element.update( player , scan(element) , prearray )
	printg()
	time.sleep(.1)
	
	
	
			
		
