class colors:

	def __init__(self):
		self.levelDict = {}
		self.backDict = {}
		
		self.reset='\033[0m'
		self.bold='\033[01m'
		self.disable='\033[02m'
		self.underline='\033[04m'
		self.reverse='\033[07m'
		self.strikethrough='\033[09m'
		self.invisible='\033[08m'
		
		self.colorsfg = {
			'black':'\033[30m',
			'red':'\033[31m',
			'green':'\033[32m',
			'orange':'\033[33m',
			'blue':'\033[34m',
			'purple':'\033[35m',
			'cyan':'\033[36m',
			'lightgrey':'\033[37m',
			'darkgrey':'\033[90m',
			'lightred':'\033[91m',
			'lightgreen':'\033[92m',
			'yellow':'\033[93m',
			'lightblue':'\033[94m',
			'pink':'\033[95m',
			'lightcyan':'\033[96m'
			}
		self.colorsbg = {
			'black':'\033[40m',
			'red':'\033[41m',
			'green':'\033[42m',
			'orange':'\033[43m',
			'blue':'\033[44m',
			'purple':'\033[45m',
			'cyan':'\033[46m',
			'lightgrey':'\033[47m'
			}
	
	def makeLevelDict(self, levelType):
		try:
			levelFile = open("colors/" + levelType + ".txt" , 'rU')
			levelStr = levelFile.read()
			levelList = levelStr.split("\n\n")
			
			for num in range(0,len(levelList)-1):
				if levelList[num][0:7] == 'COMMENT':
					levelList.pop(num)
				else:
					self.levelDict[levelList[num][0:levelList[num].index(" color ")]] = levelList[num][levelList[num].index(" color ")+7:]
					num += 1
		except:
			pass
				
	def makeBackDict(self, levelType):
		try:
			levelFile = open("colors/" + levelType + "_back.txt" , 'rU')
			levelStr = levelFile.read()
			levelList = levelStr.split("\n\n")
			
			for num in range(0,len(levelList)-1):
				if levelList[num][0:7] == 'COMMENT':
					levelList.pop(num)
				else:
					self.backDict[levelList[num][0:levelList[num].index(" color ")]] = levelList[num][levelList[num].index(" color ")+7:]
					num += 1
		except:
			pass
				
	def appendColor(self, char):
		charIn = char
	
		if charIn in self.backDict.keys():
			char = self.colorsbg[self.backDict[charIn]] + char
		if charIn in self.levelDict.keys():
			char  = self.colorsfg[self.levelDict[charIn]] + char
		char =  char + self.reset
		return char
		
	def colorize(self, text, fg, bg):
		text = self.colorsfg[fg] + self.colorsbg[bg] + text + self.reset
		return text


#Colors class:
 #   reset all colors with colors.reset
  #  two dicts fg for foreground and bg for background.
   # use as colors.subclass[colorname].
#
 #   also, the generic bold, disable, underline, reverse, strikethrough,
  #  and invisible work with the main class
   # i.e. colors.bold '''

	#credit: GI Jack, stack over flow
	#http://stackoverflow.com/questions/287871/print-in-terminal-with-colors-using-python

		
		
		
		