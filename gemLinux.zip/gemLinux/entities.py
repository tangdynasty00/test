import random

class monster(object):
	#A class that makes a new monster object
	#It will have:
	#A name
	#A symbol
	#A health value
	#An attack value
	#A range for detecting
	#X and Y coordinates
	#A speed
	#whether or not alive

	def __init__(self, name, symbol, health, attack, range, speed, alive, X, Y):
		#Returns a monster object
		self.name = name
		self.symbol = symbol
		self.health = health
		self.attack = attack
		self.range = range
		self.speed = speed
		self.alive = alive
		self.X = X
		self.Y = Y
		self.awake = "no"
		
	def hurt(self, amount):
		self.health = self.health - amount
		if self.health <= 0:
			self.alive = 'no'
			self.symbol = ';'
			
	def update(self,player,adjacents,prearray):
		#tracking
		if 1.5 <= (abs(self.X - player.X)**2 + abs(self.Y - player.Y)**2)**0.5 <= self.range:
			self.awake = "yes"
			
		if self.awake == "yes":
			if player.Y > self.Y and not('s' in adjacents):
				self.Y += 1
			elif player.Y < self.Y and not('n' in adjacents):
				self.Y -= 1
			elif player.X < self.X and not('w' in adjacents):
				self.X -= 1
			elif player.X > self.X and not('e' in adjacents):
				self.X += 1
			else:
				quickchoice = random.randint(0,4)
				if quickchoice == 0 and not ('n' in adjacents):
					self.Y -= 1
				if quickchoice == 1 and not ('s' in adjacents):
					self.Y += 1
				if quickchoice == 2 and not ('w' in adjacents):
					self.X -= 1
				if quickchoice == 3 and not ('e' in adjacents):
					self.X += 1
			
class player(object):
	#A class that makes a new player object
	#It will have:
	#A name
	#A health value
	#X and Y coordinates
	#Inventory
	#level
	#aim

	def __init__(self, name, symbol, health, attack, alive, X, Y):
		#Returns a monster object
		self.name = name
		self.symbol = symbol
		self.health = health
		self.attack = attack
		self.alive = alive
		self.X = X
		self.Y = Y
		self.inventory = []
		self.level = 1
		self.aim = 'n'
		
	def handle(self, char, adjacents, prearray):
		try:
			if char == "8" and not('n' in adjacents):
				self.Y -= 1
			if char == "2" and not('s' in adjacents):
				self.Y += 1
			if char == "4" and not('w' in adjacents):
				self.X -= 1
			if char == "6" and not('e' in adjacents):
				self.X += 1
		except:
			pass
		
	def update(self, player, adjacents, prearray):
		pass
		
		
	