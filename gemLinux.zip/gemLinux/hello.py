import os

print '\033[35m'+'color-test'+'\033[39m'+" test end"
os.system('') #enable VT100 Escape Sequence for WINDOWS 10 Ver. 1607
print '\033[35m'+ '\033[43m' + 'color-test'+'\033[39m'+" test end"