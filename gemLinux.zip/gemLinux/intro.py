import colorAdd, os, time

def colorOpen(name, colors):
	temp = open('art/' + name + '.txt', 'rU').read()
	retstr = ''
	for c in temp:
		retstr += colors.appendColor(c)
	return retstr
	
def intro():
	os.system('')
	os.system('cls')

	colors = colorAdd.colors()
	colors.makeLevelDict('TITLE')
	colors.makeBackDict('TITLE')
	
	print '\n\n\n\n\n\n\n\n' + colorOpen('title', colors)
	
	input = raw_input()	
	
	print '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'
	
	print colorOpen('titlesmall', colors)
	
	printstring = open('art/' + 'titlemenu' + '.txt', 'rU').read()
	mechstring = open('art/' + 'mechAsciiworld' + '.txt', 'rU').read()
	mechstring = mechstring.split('\n')
	printstring = printstring.split('\n')
	
	for num in range(0, len(mechstring)):
		print printstring[num] + mechstring [num]
	
	print '\n\n\n\n\n\n'
	
	input = raw_input()
	if input == '2':
		return
	
	print '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'

	print '\n\n\n' + colorOpen('cave', colors) + '\n\n\n\n'	
	print 'On June 8th, ninth month of the Kizanda Quarter in Stellar System 972-"Morrigan" ...'
	time.sleep(2)
	print 'A vast network of caves was discovered by the Morrigan Federated Mining Company ...'
	time.sleep(2)
	print 'Quick tests showed the cave system to be of incredible value in its metal deposits ... '
	time.sleep(2)
	print 'Eager to lay claim, the MFMC sent down a party of twelve mobile mining platforms ...'
	time.sleep(2)
	print '...'
	time.sleep(2)
	print 'One returned, the rest were destroyed far below...'
	time.sleep(2)
	print "It was established that the subterranean complex, dubbed 'Morrigan's lair'"
	time.sleep(2)
	print "was in fact teeming with life."
	time.sleep(5)
	
	print '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'

	print '\n\n\n' + colorOpen('prototype', colors) + '\n\n\n\n'	
	print 'This fact did not sway the MFMC.'
	time.sleep(2)
	print "The company requested military support, and was answered..."
	time.sleep(2)
	print "Private mercenary groups and Morriganian governments all lent their strength."
	time.sleep(2)
	print "Most notably, the powerful infantry war machine, since relegated to sport warfare-"
	time.sleep(2)
	print "- the Armored Saxon -"
	time.sleep(2)
	print "was revived. Research teams led a new wave of robotics research."
	time.sleep(5)
	
	print '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'

	print '\n\n\n' + colorOpen('model', colors) + '\n\n\n\n'	
	print 'But the subterranean vaults proved deeper and more forbidding than expected.'
	time.sleep(2)
	print 'A violent ecosystem of intelligent creatures lurked, and the expedition'
	time.sleep(2)
	print 'escalated into a warzone. Underground cities and cave systems served as'
	time.sleep(2)
	print 'battlegrounds.'
	time.sleep(5)
	
	print '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'

	print '\n\n\n' + colorOpen('model2', colors) + '\n\n\n\n'	
	print 'You are the pilot of a powerful Armored Saxon.'
	time.sleep(2)
	print 'Fifty tons of steel and more ammo than could fit in a house lay at your disposal.'
	time.sleep(2)
	print "As you enter the maw of Morrigan's lair, your only directive booms across"
	time.sleep(2)
	print "the radio."
	time.sleep(2)
	print colors.colorize("EXTERMINATE ALL INHUMANS!", 'yellow', 'red')
	input = raw_input()