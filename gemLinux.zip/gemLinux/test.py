# author: stefaan.himpe@gmail.com
# license: MIT
def pipe():
  from Tkinter import *
  import subprocess as sub
  p = sub.Popen(['python', 'hello.py'],stdout=sub.PIPE,stderr=sub.PIPE)
  output, errors = p.communicate()
  root = Tk()
  v = StringVar()
  text = Label(root, text = v)
  v.set(output.decode('utf-8'))
  mainloop()
  
pipe()